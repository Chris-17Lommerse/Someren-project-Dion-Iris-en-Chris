﻿namespace Someren_Applicatie.Models.Enums
{
    public enum TypeKamer
    {
        Student, Lecturer
    }
}
